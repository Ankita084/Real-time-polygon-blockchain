# Polygon POL → Binance Netflow Indexer (Rust + SQLite)

**Purpose**: Real-time indexing of POL token `Transfer` events on Polygon and computing cumulative net-flows to/from Binance addresses.

## Features
- Real-time subscription to new Polygon blocks via WebSocket
- Filters and decodes POL token Transfer events
- Identifies transfers involving predefined Binance addresses
- Stores raw transfer data in SQLite database
- Maintains cumulative net-flows (inflows - outflows) for Binance
- CLI interface for running indexer and querying current flows
- No historical backfill - starts from current block

## Prerequisites
- Rust toolchain (Rust 1.65+ recommended)
- `cargo`
- SQLite (bundled with rusqlite)
- A Polygon RPC endpoint with WebSocket support (e.g., Alchemy, QuickNode, or public endpoints)

## Setup and Build
```bash
# Clone or create project directory
mkdir polygon-pol-indexer
cd polygon-pol-indexer

# Copy project files (Cargo.toml, src/main.rs, sql/init.sql, README.md)

# Build the project
cargo build --release
```

## Usage

### Run the Indexer
```bash
# Using command-line arguments
cargo run --release -- run --rpc-url wss://polygon-mainnet.g.alchemy.com/v2/YOUR_API_KEY --db-path ./indexer.db

# Using environment variables
export RPC_URL="wss://polygon-mainnet.g.alchemy.com/v2/YOUR_API_KEY"
export DB_PATH="./indexer.db"
export POL_CONTRACT="0x455e53cbb86018ac2b8092fdcd39d8444affc3f6"  # Default POL contract
cargo run --release -- run
```

### Query Current Net-Flow
```bash
# Query the current cumulative net-flow to Binance
cargo run --release -- query --db-path ./indexer.db
```

## Database Schema
- `pol_transfers`: Raw transfer events (block_number, tx_hash, from_addr, to_addr, value, timestamp)
- `net_flows`: Aggregated flows (exchange, cumulative_in, cumulative_out, net_flow)

## Binance Addresses
The indexer monitors transfers to/from the following Binance addresses:
- 0xF977814e90dA44bFA03b6295A0616a897441aceC
- 0xe7804c37c13166fF0b37F5aE0BB07A3aEbb6e245
- 0x505e71695E9bc45943c58adEC1650577BcA68fD9
- 0x290275e3db66394C52272398959845170E4DCb88
- 0xD5C08681719445A5Fdce2Bda98b341A49050d821
- 0x082489A616aB4D46d1947eE3F912e080815b08DA

## Scalability Notes
- To add more exchanges: Extend `BINANCE_ADDRESSES` array and update database schema for multiple exchanges
- For high-throughput: Consider batching database inserts and using connection pooling
- Real-time processing: WebSocket subscription ensures low-latency event detection
- Big integer handling: Uses U256 for accurate POL value calculations (POL has 18 decimals)

## Error Handling
- Automatic reconnection on WebSocket failures
- Graceful handling of malformed logs
- Database transaction safety for consistent state

## License
MIT


To Run:
Move the project to a local directory (not OneDrive) to avoid build issues
cargo build --release
For indexer: cargo run --release -- run --rpc-url wss://polygon-mainnet.g.alchemy.com/v2/YOUR_API_KEY
For query: cargo run --release -- query