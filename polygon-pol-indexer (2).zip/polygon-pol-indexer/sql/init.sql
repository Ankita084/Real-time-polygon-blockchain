-- SQLite schema for Polygon POL Indexer

-- Table for raw POL token transfer events
CREATE TABLE IF NOT EXISTS pol_transfers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    block_number INTEGER NOT NULL,
    tx_hash TEXT NOT NULL UNIQUE,
    log_index INTEGER NOT NULL,
    from_addr TEXT NOT NULL,
    to_addr TEXT NOT NULL,
    value TEXT NOT NULL,  -- Store as string to handle large uint256
    timestamp INTEGER NOT NULL,
    UNIQUE(block_number, tx_hash, log_index)
);

-- Table for aggregated cumulative net-flows per exchange
CREATE TABLE IF NOT EXISTS net_flows (
    exchange TEXT PRIMARY KEY,
    cumulative_in TEXT NOT NULL DEFAULT '0',   -- Total POL transferred to exchange
    cumulative_out TEXT NOT NULL DEFAULT '0',  -- Total POL transferred from exchange
    net_flow TEXT NOT NULL DEFAULT '0'         -- cumulative_in - cumulative_out
);

-- Insert initial row for Binance
INSERT OR IGNORE INTO net_flows (exchange) VALUES ('binance');
