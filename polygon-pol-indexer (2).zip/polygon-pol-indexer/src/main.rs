use clap::{Parser, Subcommand};
use rusqlite::{Connection, Result as SqlResult};
use std::collections::HashSet;
use std::str::FromStr;
use web3::contract::{Contract, Options};
use web3::futures::StreamExt;
use web3::types::{Address, BlockId, BlockNumber, FilterBuilder, Log, H256, U256, U64};
use web3::types::U256;
use sha3::{Digest, Keccak256};
use hex;
use anyhow::{anyhow, Result};
use tokio;

const POL_CONTRACT_DEFAULT: &str = "0x455e53cbb86018ac2b8092fdcd39d8444affc3f6";
const BINANCE_ADDRESSES: &[&str] = &[
    "0xF977814e90dA44bFA03b6295A0616a897441aceC",
    "0xe7804c37c13166fF0b37F5aE0BB07A3aEbb6e245",
    "0x505e71695E9bc45943c58adEC1650577BcA68fD9",
    "0x290275e3db66394C52272398959845170E4DCb88",
    "0xD5C08681719445A5Fdce2Bda98b341A49050d821",
    "0x082489A616aB4D46d1947eE3F912e080815b08DA",
];

#[derive(Parser)]
#[command(name = "polygon-pol-indexer")]
#[command(about = "Real-time POL token indexer for Polygon")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Run the indexer
    Run {
        /// RPC URL (WebSocket preferred for real-time)
        #[arg(long, env = "RPC_URL")]
        rpc_url: String,
        /// Database path
        #[arg(long, env = "DB_PATH", default_value = "./indexer.db")]
        db_path: String,
        /// POL contract address
        #[arg(long, env = "POL_CONTRACT", default_value = POL_CONTRACT_DEFAULT)]
        pol_contract: String,
    },
    /// Query current net flow
    Query {
        /// Database path
        #[arg(long, env = "DB_PATH", default_value = "./indexer.db")]
        db_path: String,
    },
}

fn init_db(db_path: &str) -> Result<Connection> {
    let conn = Connection::open(db_path)?;
    let sql = std::fs::read_to_string("sql/init.sql")?;
    conn.execute_batch(&sql)?;
    Ok(conn)
}

fn get_transfer_signature() -> H256 {
    let mut hasher = Keccak256::new();
    hasher.update(b"Transfer(address,address,uint256)");
    let result = hasher.finalize();
    H256::from_slice(&result)
}

fn is_binance_address(addr: &str, binance_set: &HashSet<Address>) -> bool {
    if let Ok(address) = Address::from_str(addr) {
        binance_set.contains(&address)
    } else {
        false
    }
}

async fn process_block(
    web3: &web3::Web3<web3::transports::WebSocket>,
    conn: &Connection,
    block_number: U64,
    pol_contract: Address,
    transfer_sig: H256,
    binance_set: &HashSet<Address>,
) -> Result<()> {
    // Get block timestamp
    let block = web3.eth().block(BlockId::Number(BlockNumber::Number(block_number))).await?
        .ok_or_else(|| anyhow!("Block not found"))?;
    let timestamp = block.timestamp.as_u64() as i64;

    // Get logs for POL contract Transfer events
    let filter = FilterBuilder::default()
        .address(vec![pol_contract])
        .topics(Some(vec![transfer_sig]), None, None, None)
        .from_block(BlockNumber::Number(block_number))
        .to_block(BlockNumber::Number(block_number))
        .build();

    let logs = web3.eth().logs(filter).await?;

    for log in logs {
        if let Some((from, to, value)) = decode_transfer_log(&log) {
            // Insert raw transfer
            conn.execute(
                "INSERT OR IGNORE INTO pol_transfers (block_number, tx_hash, log_index, from_addr, to_addr, value, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)",
                rusqlite::params![block_number.as_u64() as i64, format!("{:x}", log.transaction_hash.unwrap_or_default()), log.log_index.unwrap_or_default().as_u64() as i64, format!("{:x}", from), format!("{:x}", to), value.to_string(), timestamp],
            )?;

            // Update net flows if involves binance
            let from_is_binance = binance_set.contains(&from);
            let to_is_binance = binance_set.contains(&to);

            if from_is_binance || to_is_binance {
                update_net_flows(conn, &value, from_is_binance, to_is_binance)?;
            }
        }
    }

    Ok(())
}

fn decode_transfer_log(log: &Log) -> Option<(Address, Address, U256)> {
    if log.topics.len() < 3 || log.data.0.len() < 32 {
        return None;
    }

    let from_bytes = &log.topics[1].0[12..32];
    let to_bytes = &log.topics[2].0[12..32];
    let value_bytes = &log.data.0[0..32];

    let from = Address::from_slice(from_bytes);
    let to = Address::from_slice(to_bytes);
    let value = U256::from_big_endian(value_bytes);

    Some((from, to, value))
}

fn update_net_flows(conn: &Connection, value: &U256, from_is_binance: bool, to_is_binance: bool) -> Result<()> {
    // Get current values
    let mut stmt = conn.prepare("SELECT cumulative_in, cumulative_out FROM net_flows WHERE exchange = 'binance'")?;
    let (cum_in_str, cum_out_str): (String, String) = stmt.query_row([], |row| Ok((row.get(0)?, row.get(1)?)))?;

    let mut cum_in = U256::from_dec_str(&cum_in_str).unwrap_or(U256::zero());
    let mut cum_out = U256::from_dec_str(&cum_out_str).unwrap_or(U256::zero());

    if to_is_binance {
        cum_in = cum_in + *value;
    }
    if from_is_binance {
        cum_out = cum_out + *value;
    }

    let net_flow = cum_in - cum_out;

    conn.execute(
        "UPDATE net_flows SET cumulative_in = ?, cumulative_out = ?, net_flow = ? WHERE exchange = 'binance'",
        rusqlite::params![cum_in.to_string(), cum_out.to_string(), net_flow.to_string()],
    )?;

    Ok(())
}

async fn run_indexer(rpc_url: &str, db_path: &str, pol_contract_str: &str) -> Result<()> {
    let conn = init_db(db_path)?;
    let binance_set: HashSet<Address> = BINANCE_ADDRESSES.iter()
        .filter_map(|s| Address::from_str(s).ok())
        .collect();

    let pol_contract = Address::from_str(pol_contract_str)?;
    let transfer_sig = get_transfer_signature();

    let transport = web3::transports::WebSocket::new(rpc_url).await?;
    let web3 = web3::Web3::new(transport);

    // Subscribe to new blocks
    let mut sub = web3.eth_subscribe().subscribe_new_heads().await?;

    println!("Indexer started. Listening for new blocks...");

    while let Some(block_header) = sub.next().await {
        match block_header {
            Ok(header) => {
                if let Some(block_number) = header.number {
                    println!("Processing block {}", block_number);
                    if let Err(e) = process_block(&web3, &conn, block_number, pol_contract, transfer_sig, &binance_set).await {
                        eprintln!("Error processing block {}: {}", block_number, e);
                    }
                }
            }
            Err(e) => {
                eprintln!("Subscription error: {}", e);
                // In production, handle reconnection
            }
        }
    }

    Ok(())
}

fn query_net_flow(db_path: &str) -> Result<()> {
    let conn = Connection::open(db_path)?;
    let mut stmt = conn.prepare("SELECT net_flow FROM net_flows WHERE exchange = 'binance'")?;
    let net_flow: String = stmt.query_row([], |row| row.get(0))?;
    println!("Current cumulative net-flow to Binance: {} POL", net_flow);
    Ok(())
}

#[tokio::main]
async fn main() -> Result<()> {
    let cli = Cli::parse();

    match cli.command {
        Commands::Run { rpc_url, db_path, pol_contract } => {
            run_indexer(&rpc_url, &db_path, &pol_contract).await?;
        }
        Commands::Query { db_path } => {
            query_net_flow(&db_path)?;
        }
    }

    Ok(())
}
